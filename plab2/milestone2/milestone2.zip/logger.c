#include <time.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include "logger.h"

#define SIZE 25
#define READ_END 0
#define WRITE_END 1

pid_t pid;
int fd[2];

FILE *fp;
int sequence;

int write_to_log_process(char *msg){
    if(pid < 0){
        printf("Fork failed");
        return -1;
    }
    else if(pid == 0){
        char msg_temp[SIZE];
        read(fd[READ_END],msg_temp,SIZE);
        char write_msg[100];
        char formatted_time[50];
        time_t current = time(NULL);
        struct tm *time = localtime(&current);
        strftime(formatted_time, sizeof(formatted_time), "%a %b %d %H:%M:%S %Y", time);
        snprintf(write_msg,sizeof(write_msg),"%d - %s - %s\n",sequence,formatted_time,msg_temp);

        fprintf(fp,"%s",write_msg);
        fflush(fp);

        sequence++;
    }
    else{
        write(fd[WRITE_END],msg,SIZE);
    }

    return 0;
}

int create_log_process(){
    fp = fopen("gateway.log","w");
    if(pipe(fd) == -1){
        printf("Pipe failed\n");
        return -1;
    }

    pid = fork();

    if(pid < 0){
        printf("Fork failed");
        return -1;
    }
    else if(pid == 0){
        close(fd[WRITE_END]);
    }
    else{
        close(fd[READ_END]);
    }

    return 0;
}

int end_log_process(){
    fclose(fp);
    if(pid < 0){
        printf("Fork failed");
        return -1;
    }
    else if(pid == 0){
        close(fd[READ_END]);
        exit(0);
    }
    else{
        close(fd[WRITE_END]);
        waitpid(pid,NULL,0);
    }
    return 0;
}